import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/studio_models.dart';
import '../theme/app_theme.dart';

/// Mathematically precise Islamic 8-pointed Rub el Hizb vector painter
class RubElHizbPainter extends CustomPainter {
  final Color starColor;
  final Color circleColor;

  const RubElHizbPainter({
    required this.starColor,
    required this.circleColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.5);
    final outerRadius = size.shortestSide * 0.46;
    final innerRadius = outerRadius * 0.72;

    final path = Path();
    const points = 16;
    for (int i = 0; i < points; i++) {
      final angle = (i * 2 * math.pi / points) - (math.pi / 2);
      final r = (i % 2 == 0) ? outerRadius : innerRadius;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    final paintStroke = Paint()
      ..color = starColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final paintCircle = Paint()
      ..color = circleColor
      ..style = PaintingStyle.fill;

    canvas.drawPath(path, paintStroke);
    canvas.drawCircle(center, innerRadius * 0.52, paintCircle);
  }

  @override
  bool shouldRepaint(covariant RubElHizbPainter oldDelegate) => false;
}

/// Persistent Header Language Selector Widget
/// Accessible directly from the AppBar on all 4 screens.
class HeaderLanguageButton extends StatelessWidget {
  final AppLanguage currentLanguage;
  final ValueChanged<AppLanguage> onLanguageSelected;
  final String tooltip;

  const HeaderLanguageButton({
    super.key,
    required this.currentLanguage,
    required this.onLanguageSelected,
    required this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showLanguageSelectionSheet(context),
          borderRadius: BorderRadius.circular(AppRadii.pill),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.matteGoldContainer,
              borderRadius: BorderRadius.circular(AppRadii.pill),
              border: Border.all(
                color: AppColors.matteGold.withOpacity(0.55),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.language,
                  size: 15,
                  color: AppColors.matteGold,
                ),
                const SizedBox(width: 6),
                Text(
                  currentLanguage.code.toUpperCase(),
                  style: const TextStyle(
                    color: AppColors.matteGoldLight,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(
                  Icons.arrow_drop_down,
                  size: 16,
                  color: AppColors.matteGold,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLanguageSelectionSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.midnightNavyDeep,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadii.xl)),
        side: BorderSide(color: AppColors.borderSubtle, width: 1),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.xl,
              vertical: AppSpacing.lg,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 38,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.borderProminent,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: AppSpacing.lg),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.emeraldContainer,
                        borderRadius: BorderRadius.circular(AppRadii.sm),
                        border: Border.all(color: AppColors.emeraldContainerBorder),
                      ),
                      child: const Icon(
                        Icons.translate,
                        size: 18,
                        color: AppColors.emeraldPrimary,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    const Text(
                      'Select Interface Language',
                      style: TextStyle(
                        color: AppColors.textIvory,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                ...AppLanguage.values.map((lang) {
                  final isSelected = lang == currentLanguage;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                    child: Material(
                      color: isSelected
                          ? AppColors.matteGoldContainer
                          : AppColors.surfaceNavy,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppRadii.md),
                        side: BorderSide(
                          color: isSelected
                              ? AppColors.matteGold
                              : AppColors.borderSubtle,
                          width: isSelected ? 1.5 : 1.0,
                        ),
                      ),
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(sheetContext);
                          onLanguageSelected(lang);
                        },
                        borderRadius: BorderRadius.circular(AppRadii.md),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSpacing.lg,
                            vertical: AppSpacing.md,
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      lang.nativeLabel,
                                      style: TextStyle(
                                        color: isSelected
                                            ? AppColors.matteGoldLight
                                            : AppColors.textIvory,
                                        fontSize: 15,
                                        fontWeight: isSelected
                                            ? FontWeight.bold
                                            : FontWeight.w500,
                                      ),
                                    ),
                                    Text(
                                      lang == AppLanguage.arabic
                                          ? 'Arabic (RTL)'
                                          : lang == AppLanguage.french
                                              ? 'French (Français)'
                                              : 'English (US)',
                                      style: const TextStyle(
                                        color: AppColors.textMuted,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (isSelected)
                                Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: const BoxDecoration(
                                    color: AppColors.matteGold,
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.check,
                                    size: 14,
                                    color: AppColors.midnightNavyDeep,
                                  ),
                                )
                              else
                                const SizedBox(width: 22),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Premium Studio Identity Hero Card
class StudioIdentityHeroCard extends StatelessWidget {
  final String bismillah;
  final String phaseBadge;
  final String title;
  final String description;

  const StudioIdentityHeroCard({
    super.key,
    required this.bismillah,
    required this.phaseBadge,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadii.xl),
        border: Border.all(
          color: AppColors.matteGold.withOpacity(0.4),
          width: 1,
        ),
        gradient: LinearGradient(
          colors: [
            AppColors.midnightNavyDeep,
            AppColors.midnightNavy,
            AppColors.emeraldContainer.withOpacity(0.85),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.midnightNavyDeep.withOpacity(0.72),
            offset: const Offset(0, 10),
            blurRadius: 28,
          ),
          BoxShadow(
            color: AppColors.matteGold.withOpacity(0.07),
            blurRadius: 24,
            spreadRadius: 1,
          ),
        ],
      ),
      padding: const EdgeInsets.all(AppSpacing.xl),
      child: Stack(
        children: [
          Positioned(
            right: 0,
            top: 0,
            child: Container(
              width: 92,
              height: 92,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.matteGold.withOpacity(0.32)),
                boxShadow: [
                  BoxShadow(color: AppColors.matteGold.withOpacity(0.10), blurRadius: 22),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: Image.asset(
                'assets/branding/ayah_studionext_logo.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.emeraldContainer,
                  borderRadius: BorderRadius.circular(AppRadii.pill),
                  border: Border.all(
                    color: AppColors.emeraldPrimary.withOpacity(0.55),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: AppColors.matteGold,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      phaseBadge,
                      style: const TextStyle(
                        color: AppColors.matteGoldLight,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),
              Text(
                bismillah,
                style: const TextStyle(
                  color: AppColors.matteGold,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.6,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                title,
                style: const TextStyle(
                  color: AppColors.textIvory,
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                  height: 1.3,
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                description,
                style: const TextStyle(
                  color: AppColors.textSilver,
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// In-screen Language Selector Bar (does not rely on color alone)
class LanguageSelectorBar extends StatelessWidget {
  final AppLanguage selectedLanguage;
  final ValueChanged<AppLanguage> onLanguageSelected;

  const LanguageSelectorBar({
    super.key,
    required this.selectedLanguage,
    required this.onLanguageSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: AppLanguage.values.map((language) {
        final isSelected = language == selectedLanguage;
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3.0),
            child: Material(
              color: isSelected
                  ? AppColors.matteGoldContainer
                  : AppColors.surfaceNavy,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadii.md),
                side: BorderSide(
                  color: isSelected
                      ? AppColors.matteGold
                      : AppColors.borderSubtle,
                  width: isSelected ? 1.5 : 1.0,
                ),
              ),
              child: InkWell(
                onTap: () => onLanguageSelected(language),
                borderRadius: BorderRadius.circular(AppRadii.md),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (isSelected)
                        const Padding(
                          padding: EdgeInsets.only(right: 5.0),
                          child: Icon(
                            Icons.check_circle,
                            size: 14,
                            color: AppColors.matteGold,
                          ),
                        ),
                      Text(
                        language.nativeLabel,
                        style: TextStyle(
                          color: isSelected
                              ? AppColors.matteGoldLight
                              : AppColors.textSilver,
                          fontWeight:
                              isSelected ? FontWeight.bold : FontWeight.w500,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// Architectural Module Card
class ArchitectureModuleCard extends StatelessWidget {
  final ArchitectureModuleSpec module;

  const ArchitectureModuleCard({
    super.key,
    required this.module,
  });

  @override
  Widget build(BuildContext context) {
    final isPhase1Active = module.phaseStatus.contains('Active');

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surfaceNavy,
        borderRadius: BorderRadius.circular(AppRadii.md),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      module.directoryName,
                      style: const TextStyle(
                        color: AppColors.matteGold,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text('•', style: TextStyle(color: AppColors.textMuted)),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        module.title,
                        style: const TextStyle(
                          color: AppColors.textIvory,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  module.summary,
                  style: const TextStyle(
                    color: AppColors.textSilver,
                    fontSize: 12,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isPhase1Active
                  ? AppColors.emeraldContainer
                  : AppColors.surfaceElevated,
              borderRadius: BorderRadius.circular(AppRadii.pill),
              border: Border.all(
                color: isPhase1Active
                    ? AppColors.emeraldPrimary.withOpacity(0.5)
                    : AppColors.borderSubtle,
              ),
            ),
            child: Text(
              module.phaseStatus,
              style: TextStyle(
                color: isPhase1Active ? AppColors.emeraldSoft : AppColors.textMuted,
                fontSize: 10,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Workspace Destination Card
class WorkspaceDestinationCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const WorkspaceDestinationCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: AppColors.surfaceNavy,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadii.lg),
          side: BorderSide(
            color: AppColors.matteGold.withOpacity(0.35),
            width: 1,
          ),
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppRadii.lg),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppColors.emeraldContainer,
                    borderRadius: BorderRadius.circular(AppRadii.md),
                    border: Border.all(
                      color: AppColors.emeraldContainerBorder,
                    ),
                  ),
                  child: Icon(
                    icon,
                    color: AppColors.matteGold,
                    size: 22,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: AppColors.textIvory,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: AppColors.textSilver,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.arrow_forward_ios,
                  size: 13,
                  color: AppColors.matteGoldLight,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Foundation Scope Card for Phase Placeholders
class FoundationScopeCard extends StatelessWidget {
  final String badgeText;
  final String title;
  final String subtitle;
  final String scopeHeader;
  final List<String> points;
  final IconData icon;

  const FoundationScopeCard({
    super.key,
    required this.badgeText,
    required this.title,
    required this.subtitle,
    required this.scopeHeader,
    required this.points,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceNavy,
        borderRadius: BorderRadius.circular(AppRadii.xl),
        border: Border.all(
          color: AppColors.matteGold.withOpacity(0.35),
        ),
      ),
      padding: const EdgeInsets.all(AppSpacing.xl),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: AppColors.emeraldContainer,
                  borderRadius: BorderRadius.circular(AppRadii.md),
                  border: Border.all(
                    color: AppColors.emeraldContainerBorder,
                  ),
                ),
                child: Icon(
                  icon,
                  color: AppColors.matteGold,
                  size: 24,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      badgeText,
                      style: const TextStyle(
                        color: AppColors.emeraldSoft,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      title,
                      style: const TextStyle(
                        color: AppColors.textIvory,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Text(
            subtitle,
            style: const TextStyle(
              color: AppColors.textSilver,
              fontSize: 13,
              height: 1.4,
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          Container(
            decoration: BoxDecoration(
              color: AppColors.midnightNavyDeep.withOpacity(0.7),
              borderRadius: BorderRadius.circular(AppRadii.md),
              border: Border.all(color: AppColors.borderSubtle),
            ),
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.map_outlined,
                      size: 16,
                      color: AppColors.matteGold,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      scopeHeader,
                      style: const TextStyle(
                        color: AppColors.matteGoldLight,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                ...points.map((point) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(top: 6),
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: AppColors.emeraldPrimary,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            point,
                            style: const TextStyle(
                              color: AppColors.textSilver,
                              fontSize: 12,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
