import 'package:flutter/material.dart';

/// Centralized Design System Tokens for AyahStudioNext
/// AyahStudioNext Sacred Modernism — official brand tokens.
/// Midnight #0A0E12 · Surface #131B22 · Emerald #0F3D3E
/// Mushaf Gold #D4AF37 · Light Ivory #FAF8F5
class AppColors {
  // Midnight Navy Foundations
  static const Color midnightNavyDeep = Color(0xFF0A0E12);
  static const Color midnightNavy = Color(0xFF0A0E12);
  static const Color surfaceNavy = Color(0xFF131B22);
  static const Color surfaceElevated = Color(0xFF1B292D);
  static const Color surfaceGlass = Color(0x33131B22);
  static const Color borderSubtle = Color(0xFF29413E);
  static const Color borderProminent = Color(0xFF42645B);

  // Emerald Green Accents & Containers
  static const Color emeraldPrimary = Color(0xFF0F3D3E);
  static const Color emeraldLight = Color(0xFF0F3D3E);
  static const Color emeraldSoft = Color(0xFFFAF8F5);
  static const Color emeraldContainer = Color(0xFF123B36);
  static const Color emeraldContainerBorder = Color(0xFF28645A);

  // Luxury Matte Gold Highlights & Borders
  static const Color matteGold = Color(0xFFD4AF37);
  static const Color matteGoldLight = Color(0xFFEBD58A);
  static const Color matteGoldMuted = Color(0xFF9A7A2B);
  static const Color matteGoldContainer = Color(0xFF302711);
  static const Color matteGoldBorder = Color(0xFF806A2D);

  // High-legibility Typography & Content
  static const Color textIvory = Color(0xFFFAF8F5);
  static const Color textSilver = Color(0xFFC7CBC5);
  static const Color textMuted = Color(0xFF899791);

  // Utility
  static const Color error = Color(0xFFE05A47);
  static const Color success = Color(0xFF0F3D3E);
}

class AppRadii {
  static const double sm = 8.0;
  static const double md = 14.0;
  static const double lg = 20.0;
  static const double xl = 26.0;
  static const double pill = 50.0;
}

class AppSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 12.0;
  static const double lg = 16.0;
  static const double xl = 20.0;
  static const double xxl = 28.0;
}

class AppDurations {
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration normal = Duration(milliseconds: 250);
  static const Duration smooth = Duration(milliseconds: 350);
}

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.midnightNavy,
      primaryColor: AppColors.matteGold,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.matteGold,
        onPrimary: AppColors.midnightNavyDeep,
        primaryContainer: AppColors.matteGoldContainer,
        onPrimaryContainer: AppColors.matteGoldLight,
        secondary: AppColors.emeraldPrimary,
        onSecondary: AppColors.midnightNavyDeep,
        secondaryContainer: AppColors.emeraldContainer,
        onSecondaryContainer: AppColors.emeraldSoft,
        surface: AppColors.surfaceNavy,
        onSurface: AppColors.textIvory,
        surfaceContainerHighest: AppColors.surfaceElevated,
        outline: AppColors.borderSubtle,
        outlineVariant: AppColors.borderProminent,
        error: AppColors.error,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.midnightNavyDeep,
        foregroundColor: AppColors.textIvory,
        elevation: 0,
        centerTitle: false,
        scrolledUnderElevation: 2,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceElevated,
        labelStyle: const TextStyle(color: AppColors.textSilver),
        hintStyle: const TextStyle(color: AppColors.textMuted),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.md),
          borderSide: const BorderSide(color: AppColors.borderSubtle),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.md),
          borderSide: const BorderSide(color: AppColors.matteGold, width: 1.4),
        ),
      ),
      cardTheme: CardThemeData(
        color: AppColors.surfaceNavy,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadii.lg),
          side: const BorderSide(color: AppColors.borderSubtle, width: 1),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.midnightNavyDeep,
        selectedItemColor: AppColors.matteGold,
        unselectedItemColor: AppColors.textMuted,
        selectedLabelStyle: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.2,
        ),
        unselectedLabelStyle: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
        type: BottomNavigationBarType.fixed,
        elevation: 10,
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.borderSubtle,
        thickness: 1,
        space: 24,
      ),
    );
  }
}
