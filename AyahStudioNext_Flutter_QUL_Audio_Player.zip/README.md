# ayah_studio_next

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


## QUL word timing data integration
- Original resource: Mishari Rashid al-`Afasy Streaming (surah-by-surah).
- Added assets: `assets/quran/qul_segments.json`, `assets/quran/surah_audio.json`.
- Added loader/audit service: `lib/services/quran_timing_service.dart`.
- Review report: `assets/quran/timing_review.csv` (51 flagged segments: 32 zero-duration and 19 reversed).
- Original timestamps are not modified. Segments with `end_ms <= start_ms` are marked for review; no replacement times are guessed.
- Data is not fully verified against audio yet. The current Quran Studio screen is not yet wired to word-level playback/highlighting, and this package has not been built into an APK in this environment.


## Quran Studio audio step (added)

- Added a surah selector for the 114 entries present in the supplied QUL surah-audio metadata. The current labels are numbered `Surah 1` through `Surah 114`; Arabic surah names have not been fabricated.
- Added Mishari Al-Afasy streaming playback controls (play/pause/stop, seek bar and elapsed/total time) using `just_audio`. Internet permission is declared for Android.
- Added a timing-data status panel. Original QUL timestamps remain unchanged; invalid/zero-duration segments are flagged, not repaired.
- Word-level highlight synchronization, ayah-range editing, video backgrounds, and MP4 export are not implemented in this step.

**Validation status:** This environment does not have the Flutter CLI, so `flutter pub get`, analyzer, device playback and APK build have not been run. Treat this as a source update awaiting a real Flutter build/test, not a verified APK. Audio requires an internet connection.
