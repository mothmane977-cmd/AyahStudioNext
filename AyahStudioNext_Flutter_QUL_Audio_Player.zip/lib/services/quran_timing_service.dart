import 'dart:convert';
import 'package:flutter/services.dart';

class QuranWordSegment {
  final int wordPosition;
  final int startMs;
  final int endMs;
  final bool needsReview;

  const QuranWordSegment({
    required this.wordPosition,
    required this.startMs,
    required this.endMs,
    required this.needsReview,
  });

  factory QuranWordSegment.fromList(List<dynamic> raw) {
    final start = (raw[1] as num).toInt();
    final end = (raw[2] as num).toInt();
    return QuranWordSegment(
      wordPosition: (raw[0] as num).toInt(),
      startMs: start,
      endMs: end,
      needsReview: end <= start,
    );
  }
}

class QuranTimingSummary {
  final int verseCount;
  final int segmentCount;
  final int reviewCount;
  final int zeroDurationCount;
  final int reversedCount;

  const QuranTimingSummary({
    required this.verseCount,
    required this.segmentCount,
    required this.reviewCount,
    required this.zeroDurationCount,
    required this.reversedCount,
  });
}

/// Loads the original QUL timestamps without repairing or guessing values.
/// A segment with end <= start is marked as needing review.
class QuranTimingService {
  static const _segmentsAsset = 'assets/quran/qul_segments.json';
  static const _surahAsset = 'assets/quran/surah_audio.json';

  Future<Map<String, dynamic>> loadSegments() async {
    final raw = await rootBundle.loadString(_segmentsAsset);
    return (jsonDecode(raw) as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> loadSurahAudio() async {
    final raw = await rootBundle.loadString(_surahAsset);
    return (jsonDecode(raw) as Map<String, dynamic>);
  }

  Future<QuranTimingSummary> getSummary() async {
    final data = await loadSegments();
    var segmentCount = 0;
    var reviewCount = 0;
    var zeroDurationCount = 0;
    var reversedCount = 0;

    for (final verse in data.values) {
      if (verse is! Map<String, dynamic>) continue;
      final rawSegments = verse['segments'];
      if (rawSegments is! List) continue;
      for (final item in rawSegments) {
        if (item is! List || item.length < 3) {
          reviewCount++;
          continue;
        }
        segmentCount++;
        final start = (item[1] as num).toInt();
        final end = (item[2] as num).toInt();
        if (end == start) {
          zeroDurationCount++;
          reviewCount++;
        } else if (end < start) {
          reversedCount++;
          reviewCount++;
        }
      }
    }

    return QuranTimingSummary(
      verseCount: data.length,
      segmentCount: segmentCount,
      reviewCount: reviewCount,
      zeroDurationCount: zeroDurationCount,
      reversedCount: reversedCount,
    );
  }

  Future<List<QuranWordSegment>> getVerseSegments(String verseKey) async {
    final data = await loadSegments();
    final verse = data[verseKey];
    if (verse is! Map<String, dynamic> || verse['segments'] is! List) {
      return const [];
    }
    return (verse['segments'] as List)
        .whereType<List<dynamic>>()
        .where((item) => item.length >= 3)
        .map(QuranWordSegment.fromList)
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> getSurahAudio(int surahNumber) async {
    final data = await loadSurahAudio();
    final value = data['$surahNumber'];
    if (value is Map<String, dynamic>) return value;
    return null;
  }
}
