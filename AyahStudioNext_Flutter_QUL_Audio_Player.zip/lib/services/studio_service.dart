import 'package:flutter/foundation.dart';
import '../models/studio_models.dart';

class StudioService extends ChangeNotifier {
  StudioDestination _currentDestination = StudioDestination.home;
  AppLanguage _selectedLanguage = AppLanguage.english;

  StudioDestination get currentDestination => _currentDestination;
  AppLanguage get selectedLanguage => _selectedLanguage;

  void selectDestination(StudioDestination destination) {
    if (_currentDestination != destination) {
      _currentDestination = destination;
      notifyListeners();
    }
  }

  void selectLanguage(AppLanguage language) {
    if (_selectedLanguage != language) {
      _selectedLanguage = language;
      notifyListeners();
    }
  }
}
