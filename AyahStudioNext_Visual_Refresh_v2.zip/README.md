# ayah_studio_next

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


## QUL word timing data integration
- Original resource: Mishari Rashid al-`Afasy Streaming (surah-by-surah).
- Added assets: `assets/quran/qul_segments.json`, `assets/quran/surah_audio.json`.
- Added loader/audit service: `lib/services/quran_timing_service.dart`.
- Review report: `assets/quran/timing_review.csv` (51 flagged segments: 32 zero-duration and 19 reversed).
- Original timestamps are not modified. Segments with `end_ms <= start_ms` are marked for review; no replacement times are guessed.
- Data is not fully verified against audio yet. The current Quran Studio screen is not yet wired to word-level playback/highlighting, and this package has not been built into an APK in this environment.


## Quran Studio audio step (added)

- Added a surah selector for the 114 entries present in the supplied QUL surah-audio metadata. The current labels are numbered `Surah 1` through `Surah 114`; Arabic surah names have not been fabricated.
- Added Mishari Al-Afasy streaming playback controls (play/pause/stop, seek bar and elapsed/total time) using `just_audio`. Internet permission is declared for Android.
- Added a timing-data status panel. Original QUL timestamps remain unchanged; invalid/zero-duration segments are flagged, not repaired.
- Word-level highlight synchronization, ayah-range editing, video backgrounds, and MP4 export are not implemented in this step.

**Validation status:** This environment does not have the Flutter CLI, so `flutter pub get`, analyzer, device playback and APK build have not been run. Treat this as a source update awaiting a real Flutter build/test, not a verified APK. Audio requires an internet connection.


## Sacred Modernism visual identity pass (2026-10-29)
- Added the exact user-approved logo image at `assets/branding/ayah_studionext_logo.png`.
- Registered the logo asset in `pubspec.yaml` and displayed it in the app bar and home identity hero.
- Replaced the Android launcher icon density assets with resized copies of the same approved logo.
- Updated centralized UI color tokens to the official brand palette: `#0A0E12`, `#131B22`, `#0F3D3E`, `#D4AF37`, and `#FAF8F5`.
- Added dark glass-style input surfaces and gold focus borders.
- Reframed the Quran Studio top area as a static 9:16 preview concept using the official logo; it is explicitly not a functioning video renderer.
- Moved QUL timing counters into an expandable advanced diagnostics section to keep technical data out of the primary user flow.
- No Quran audio, timing JSON, localization, or playback service data was intentionally modified.
- Flutter/Dart CLI is not installed in the editing environment; `flutter pub get`, `flutter analyze`, tests, and APK build remain to be run in GitHub Actions or a Flutter environment.
