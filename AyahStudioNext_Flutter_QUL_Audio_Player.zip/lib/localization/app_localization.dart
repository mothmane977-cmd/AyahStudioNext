import '../models/studio_models.dart';

class LocalizedStrings {
  final String appTitle;
  final String appSubtitle;
  final String bismillahHeader;
  final String phaseBadge;
  final String navHome;
  final String navQuranStudio;
  final String navAdhkar;
  final String navSettings;
  final String homeHeroTitle;
  final String homeHeroDescription;
  final String architectureSectionTitle;
  final String architectureSectionSubtitle;
  final String quickNavSectionTitle;
  final String studioPlaceholderTitle;
  final String studioPlaceholderSubtitle;
  final String studioPlannedScopeTitle;
  final List<String> studioPlannedPoints;
  final String adhkarPlaceholderTitle;
  final String adhkarPlaceholderSubtitle;
  final String adhkarPlannedScopeTitle;
  final List<String> adhkarPlannedPoints;
  final String settingsPlaceholderTitle;
  final String settingsPlaceholderSubtitle;
  final String languageSettingLabel;
  final String changeLanguageTooltip;
  final String environmentInfoTitle;
  final String activeIndicator;
  final List<ArchitectureModuleSpec> modules;

  const LocalizedStrings({
    required this.appTitle,
    required this.appSubtitle,
    required this.bismillahHeader,
    required this.phaseBadge,
    required this.navHome,
    required this.navQuranStudio,
    required this.navAdhkar,
    required this.navSettings,
    required this.homeHeroTitle,
    required this.homeHeroDescription,
    required this.architectureSectionTitle,
    required this.architectureSectionSubtitle,
    required this.quickNavSectionTitle,
    required this.studioPlaceholderTitle,
    required this.studioPlaceholderSubtitle,
    required this.studioPlannedScopeTitle,
    required this.studioPlannedPoints,
    required this.adhkarPlaceholderTitle,
    required this.adhkarPlaceholderSubtitle,
    required this.adhkarPlannedScopeTitle,
    required this.adhkarPlannedPoints,
    required this.settingsPlaceholderTitle,
    required this.settingsPlaceholderSubtitle,
    required this.languageSettingLabel,
    required this.changeLanguageTooltip,
    required this.environmentInfoTitle,
    required this.activeIndicator,
    required this.modules,
  });
}

class AppLocalization {
  static LocalizedStrings forLanguage(AppLanguage language) {
    switch (language) {
      case AppLanguage.english:
        return _english;
      case AppLanguage.french:
        return _french;
      case AppLanguage.arabic:
        return _arabic;
    }
  }

  static const LocalizedStrings _english = LocalizedStrings(
    appTitle: 'AyahStudioNext',
    appSubtitle: 'Quranic Video Creation Studio',
    bismillahHeader: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    phaseBadge: 'Phase 1 • Midnight & Matte Gold System',
    navHome: 'Home',
    navQuranStudio: 'Quran Studio',
    navAdhkar: 'Adhkar',
    navSettings: 'Settings',
    homeHeroTitle: 'Sacred Typography & Cinematic Studio Identity',
    homeHeroDescription:
        'Refined Islamic design system in Midnight Navy (#0B132B), Emerald (#2A9D8F), and Matte Gold (#E9C46A). Built for Reels & Shorts creation with persistent trilingual access.',
    architectureSectionTitle: 'Architectural Foundations',
    architectureSectionSubtitle:
        'Decoupled module architecture prepared for incremental studio features',
    quickNavSectionTitle: 'Studio Workspaces',
    studioPlaceholderTitle: 'Quran Studio Workspace',
    studioPlaceholderSubtitle:
        'Unified creation shell ready for Free Editing & Ready-Made Templates.',
    studioPlannedScopeTitle: 'Planned Studio Capabilities (Roadmap)',
    studioPlannedPoints: [
      'Two creation modes: Ready-Made Templates & Free Editing canvas',
      'Verified Uthmani script with separate Saheeh International & Hamidullah translations',
      'High-fidelity reciter audio with millisecond timestamp synchronization & manual scrubber',
      'Arabic calligraphy styling: glow, typography scale, position, and diacritics',
      'Multi-track timeline with 9:16 Reels preview and configurable MP4 export',
    ],
    adhkarPlaceholderTitle: 'Islamic Adhkar & Social Cards',
    adhkarPlaceholderSubtitle:
        'Sourced daily remembrances and shareable Islamic card creation.',
    adhkarPlannedScopeTitle: 'Planned Adhkar Capabilities (Roadmap)',
    adhkarPlannedPoints: [
      'Authentic Morning, Evening, Sleep, and After-Prayer Adhkar with translations',
      'Interactive repetition counter with gentle haptic and audio feedback',
      'Islamic social card creator with custom typography, borders, and image exports',
      'Configurable daily notification reminders',
    ],
    settingsPlaceholderTitle: 'Studio & Localization Preferences',
    settingsPlaceholderSubtitle:
        'Interface language (Arabic RTL, French, English) and build environment parameters.',
    languageSettingLabel: 'Interface Language',
    changeLanguageTooltip: 'Change Language / Changer de langue / تغيير اللغة',
    environmentInfoTitle: 'Verified Environment & Build Metadata',
    activeIndicator: 'Selected',
    modules: [
      ArchitectureModuleSpec(
        id: 'theme',
        directoryName: 'theme/',
        title: 'Design System',
        summary: 'Midnight Navy, Emerald Green, and Matte Gold tokens',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'widgets',
        directoryName: 'widgets/',
        title: 'Reusable Widgets',
        summary: 'Rub el Hizb vector art, hero cards, and header language bar',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'screens',
        directoryName: 'screens/',
        title: 'Navigation Screens',
        summary: 'Polished Home, Studio, Adhkar, and Settings views',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'localization',
        directoryName: 'localization/',
        title: 'Trilingual Engine',
        summary: 'Persistent header switcher for Arabic (RTL), French, and English',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'models',
        directoryName: 'models/',
        title: 'Domain Models',
        summary: 'Navigation, language, and future studio project state contracts',
        phaseStatus: 'Foundation',
      ),
      ArchitectureModuleSpec(
        id: 'video_editing',
        directoryName: 'video_editing/',
        title: 'Video Engine Contract',
        summary: 'Lightweight interfaces reserved for timeline, canvas, and MP4 export',
        phaseStatus: 'Deferred (Phase 6)',
      ),
    ],
  );

  static const LocalizedStrings _french = LocalizedStrings(
    appTitle: 'AyahStudioNext',
    appSubtitle: 'Studio de Création Vidéo Coranique',
    bismillahHeader: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    phaseBadge: 'Phase 1 • Système Bleu Nuit & Or Mat',
    navHome: 'Accueil',
    navQuranStudio: 'Studio Coran',
    navAdhkar: 'Adhkar',
    navSettings: 'Paramètres',
    homeHeroTitle: 'Typographie Sacrée & Identité Visuelle Cinématique',
    homeHeroDescription:
        'Système de design raffiné en Bleu Nuit (#0B132B), Émeraude (#2A9D8F) et Or Mat (#E9C46A). Conçu pour la création de Reels & Shorts avec accès trilingue permanent.',
    architectureSectionTitle: 'Fondations Architecturales',
    architectureSectionSubtitle:
        'Architecture modulaire découplée préparée pour les fonctionnalités incrémentales',
    quickNavSectionTitle: 'Espaces du Studio',
    studioPlaceholderTitle: 'Espace Studio Coranique',
    studioPlaceholderSubtitle:
        'Cadre de création unifié prêt pour les Modèles Prêts et l\'Édition Libre.',
    studioPlannedScopeTitle: 'Fonctionnalités Prévues du Studio (Feuille de Route)',
    studioPlannedPoints: [
      'Deux modes : Modèles Prêts à l\'emploi & Canevas d\'Édition Libre',
      'Texte Uthmani vérifié avec traductions distinctes (Hamidullah & Saheeh Int.)',
      'Récitation audio haute fidélité avec synchronisation précise par horodatage',
      'Stylisation calligraphique arabe : lueur, échelle, positionnement et diacritiques',
      'Chronologie multi-pistes avec aperçu Reels 9:16 et exportation MP4 configurable',
    ],
    adhkarPlaceholderTitle: 'Adhkar Islamiques & Cartes Réseaux',
    adhkarPlaceholderSubtitle:
        'Invocations quotidiennes authentiques et création de cartes à partager.',
    adhkarPlannedScopeTitle: 'Fonctionnalités Prévues des Adhkar (Feuille de Route)',
    adhkarPlannedPoints: [
      'Adhkar authentiques (matin, soir, sommeil, prière) avec traduction',
      'Compteur de répétitions interactif avec retours discrets',
      'Créateur de cartes islamiques avec calligraphies et cadres géométriques',
      'Rappels quotidiens configurables par notification',
    ],
    settingsPlaceholderTitle: 'Préférences du Studio & Langue',
    settingsPlaceholderSubtitle:
        'Langue de l\'interface (Arabe RTL, Français, Anglais) et métadonnées de construction.',
    languageSettingLabel: 'Langue de l\'Interface',
    changeLanguageTooltip: 'Changer de langue / Change Language / تغيير اللغة',
    environmentInfoTitle: 'Environnement Vérifié & Métadonnées',
    activeIndicator: 'Sélectionné',
    modules: [
      ArchitectureModuleSpec(
        id: 'theme',
        directoryName: 'theme/',
        title: 'Système de Design',
        summary: 'Jetons Bleu Nuit, Émeraude et Or Mat appliqués',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'widgets',
        directoryName: 'widgets/',
        title: 'Composants Réutilisables',
        summary: 'Art Rub el Hizb, bannières et sélecteur d\'en-tête',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'screens',
        directoryName: 'screens/',
        title: 'Écrans de Navigation',
        summary: 'Vues soignées Accueil, Studio, Adhkar et Paramètres',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'localization',
        directoryName: 'localization/',
        title: 'Moteur Trilingue',
        summary: 'Sélecteur permanent en en-tête pour Arabe (RTL), Français et Anglais',
        phaseStatus: 'Phase 1 Active',
      ),
      ArchitectureModuleSpec(
        id: 'models',
        directoryName: 'models/',
        title: 'Modèles Métier',
        summary: 'Contrats pour la navigation, la langue et les projets futurs',
        phaseStatus: 'Fondation',
      ),
      ArchitectureModuleSpec(
        id: 'video_editing',
        directoryName: 'video_editing/',
        title: 'Contrat Édition Vidéo',
        summary: 'Interfaces légères réservées pour le canevas et le rendu MP4',
        phaseStatus: 'Différé (Phase 6)',
      ),
    ],
  );

  static const LocalizedStrings _arabic = LocalizedStrings(
    appTitle: 'آية ستوديو نكست',
    appSubtitle: 'استوديو صناعة مقاطع الفيديو القرآنية',
    bismillahHeader: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    phaseBadge: 'المرحلة ١ • نظام الكحلي الليلي والذهب المطفي',
    navHome: 'الرئيسية',
    navQuranStudio: 'استوديو القرآن',
    navAdhkar: 'الأذكار',
    navSettings: 'الإعدادات',
    homeHeroTitle: 'الخط القرآني الأصيل والهوية البصرية السينمائية',
    homeHeroDescription:
        'نظام تصميم إسلامي فاخر يدمج الكحلي الليلي (#0B132B) والزمردي (#2A9D8F) والذهب المطفي (#E9C46A). صُمم لصناعة مقاطع الريلز والقصيرة مع دعم دائم لتعدد اللغات.',
    architectureSectionTitle: 'الأسس المعمارية للتطبيق',
    architectureSectionSubtitle:
        'هيكل برمجي معياري منفصل ومهيأ لإضافة ميزات الاستوديو بشكل تدريجي',
    quickNavSectionTitle: 'مساحات الاستوديو',
    studioPlaceholderTitle: 'مساحة استوديو القرآن الكريم',
    studioPlaceholderSubtitle:
        'واجهة العمل الموحدة جاهزة لنمطي القوالب الجاهزة والتحرير الحر.',
    studioPlannedScopeTitle: 'الخصائص المخططة للاستوديو (خريطة الطريق)',
    studioPlannedPoints: [
      'نمطان للإنشاء: القوالب الجاهزة الفاخرة ومساحة التحرير الحر المفتوحة',
      'نص عثماني موثق مع فصل تام للترجمات المعتمدة (صحيح إنترناشونال ومحمد حميد الله)',
      'تلاوات صوتية عالية النقاء مع مزامنة دقيقة بالأجزاء من الثانية ومحرر يدوي',
      'تخصيص الخطوط والوهج الذهبي ومواقع النصوص وضبط علامات الوقف والتشكيل',
      'شريط زمني متعدد المسارات مع معاينة حية بمقاس 9:16 وتصدير فيديو MP4',
    ],
    adhkarPlaceholderTitle: 'الأذكار الإسلامية والبطاقات الدعوية',
    adhkarPlaceholderSubtitle:
        'أذكار يومية موثوقة المصدر وأداة لتصميم بطاقات النشر الاجتماعية.',
    adhkarPlannedScopeTitle: 'الخصائص المخططة لقسم الأذكار (خريطة الطريق)',
    adhkarPlannedPoints: [
      'أذكار الصباح والمساء والنوم وما بعد الصلاة بالنصوص الموثقة والترجمة',
      'عداد تسبيح تفاعلي مع استجابة اهتزازية وصوتية هادئة',
      'أداة تصميم بطاقات قرآنية ودعوية بخلفيات وزخارف إسلامية قابلة للمشاركة',
      'جدولة الإشعارات والتذكيرات اليومية القابلة للتخصيص',
    ],
    settingsPlaceholderTitle: 'إعدادات الاستوديو واللغة',
    settingsPlaceholderSubtitle:
        'لغة الواجهة (العربية من اليمين لليسار، الفرنسية، الإنجليزية) وبيانات بيئة البناء.',
    languageSettingLabel: 'لغة الواجهة',
    changeLanguageTooltip: 'تغيير اللغة / Change Language / Changer de langue',
    environmentInfoTitle: 'بيانات بيئة البناء المعتمدة',
    activeIndicator: 'محدد',
    modules: [
      ArchitectureModuleSpec(
        id: 'theme',
        directoryName: 'theme/',
        title: 'نظام التصميم',
        summary: 'تطبيق ألوان الكحلي الليلي والزمردي والذهب المطفي بالكامل',
        phaseStatus: 'المرحلة ١ نشطة',
      ),
      ArchitectureModuleSpec(
        id: 'widgets',
        directoryName: 'widgets/',
        title: 'المكونات المشتركة',
        summary: 'زخرفة نجمة ربع الحزب المتجهة وبطاقات العرض وزر تبديل اللغة العلوي',
        phaseStatus: 'المرحلة ١ نشطة',
      ),
      ArchitectureModuleSpec(
        id: 'screens',
        directoryName: 'screens/',
        title: 'شاشات التنقل',
        summary: 'واجهات مصقولة للرئيسية والاستوديو والأذكار والإعدادات',
        phaseStatus: 'المرحلة ١ نشطة',
      ),
      ArchitectureModuleSpec(
        id: 'localization',
        directoryName: 'localization/',
        title: 'محرك اللغات',
        summary: 'زر دائم في الشريط العلوي للتبديل بين العربية والفرنسية والإنجليزية',
        phaseStatus: 'المرحلة ١ نشطة',
      ),
      ArchitectureModuleSpec(
        id: 'models',
        directoryName: 'models/',
        title: 'نماذج البيانات',
        summary: 'عقود تعريف الحالة ومسارات التنقل ومشاريع الاستوديو المستقبلية',
        phaseStatus: 'تأسيس',
      ),
      ArchitectureModuleSpec(
        id: 'video_editing',
        directoryName: 'video_editing/',
        title: 'عقود تحرير الفيديو',
        summary: 'واجهات خفيفة مخصصة للشريط الزمني ومعاينة القماش وتصدير MP4',
        phaseStatus: 'مؤجل (المرحلة ٦)',
      ),
    ],
  );
}
