import 'package:flutter/material.dart';
import '../localization/app_localization.dart';
import '../models/studio_models.dart';
import '../theme/app_theme.dart';
import '../widgets/studio_widgets.dart';

class SettingsScreen extends StatelessWidget {
  final LocalizedStrings strings;
  final AppLanguage selectedLanguage;
  final ValueChanged<AppLanguage> onLanguageSelected;

  const SettingsScreen({
    super.key,
    required this.strings,
    required this.selectedLanguage,
    required this.onLanguageSelected,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.lg,
      ),
      children: [
        Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceNavy,
            borderRadius: BorderRadius.circular(AppRadii.xl),
            border: Border.all(
              color: AppColors.matteGold.withOpacity(0.35),
            ),
          ),
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.emeraldContainer,
                      borderRadius: BorderRadius.circular(AppRadii.sm),
                      border: Border.all(color: AppColors.emeraldContainerBorder),
                    ),
                    child: const Icon(
                      Icons.translate,
                      size: 16,
                      color: AppColors.matteGold,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Text(
                    strings.settingsPlaceholderTitle,
                    style: const TextStyle(
                      color: AppColors.textIvory,
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                strings.settingsPlaceholderSubtitle,
                style: const TextStyle(
                  color: AppColors.textSilver,
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              Text(
                strings.languageSettingLabel,
                style: const TextStyle(
                  color: AppColors.matteGoldLight,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.2,
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              LanguageSelectorBar(
                selectedLanguage: selectedLanguage,
                onLanguageSelected: onLanguageSelected,
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.lg),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceNavy,
            borderRadius: BorderRadius.circular(AppRadii.xl),
            border: Border.all(color: AppColors.borderSubtle),
          ),
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.emeraldContainer,
                      borderRadius: BorderRadius.circular(AppRadii.sm),
                      border: Border.all(color: AppColors.emeraldContainerBorder),
                    ),
                    child: const Icon(
                      Icons.verified_outlined,
                      size: 16,
                      color: AppColors.emeraldPrimary,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Text(
                    strings.environmentInfoTitle,
                    style: const TextStyle(
                      color: AppColors.matteGoldLight,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.lg),
              _buildMetadataRow('Application Name', 'AyahStudioNext'),
              const Divider(color: AppColors.borderSubtle, height: 20),
              _buildMetadataRow('Framework', 'Flutter 3.24.5 / Dart 3.5.4'),
              const Divider(color: AppColors.borderSubtle, height: 20),
              _buildMetadataRow(
                  'Package ID', 'com.aistudio.ayahstudionext.ayah_studio_next'),
              const Divider(color: AppColors.borderSubtle, height: 20),
              _buildMetadataRow('Android Embedding', 'Flutter Embedding v2'),
              const Divider(color: AppColors.borderSubtle, height: 20),
              _buildMetadataRow(
                'Active UI Locale',
                '${selectedLanguage.nativeLabel} (${selectedLanguage.code.toUpperCase()})',
              ),
              const Divider(color: AppColors.borderSubtle, height: 20),
              _buildMetadataRow('Active Design System', 'Phase 1 • Midnight & Matte Gold'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMetadataRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: AppColors.textSilver,
            fontSize: 13,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: AppColors.emeraldSoft,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
