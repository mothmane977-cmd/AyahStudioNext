package com.aistudio.ayahstudionext.ayah_studio_next

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
