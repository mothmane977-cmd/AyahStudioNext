enum AspectRatioPreset {
  reelsPortrait('9:16 Portrait', 9, 16),
  squarePost('1:1 Square', 1, 1),
  cinemaLandscape('16:9 Landscape', 16, 9);

  const AspectRatioPreset(this.label, this.widthRatio, this.heightRatio);

  final String label;
  final int widthRatio;
  final int heightRatio;
}

enum SyncMode {
  automaticTimestamps,
  manualKeyframes,
}

abstract class VideoTimelineContract {
  String get enginePhaseStatus;
  List<AspectRatioPreset> get supportedAspectRatios;
  List<SyncMode> get supportedSyncModes;
}

class PhaseOneVideoEngineStub implements VideoTimelineContract {
  const PhaseOneVideoEngineStub();

  @override
  String get enginePhaseStatus =>
      'Phase 1 Contract Only (Zero heavy FFmpeg or rendering dependencies)';

  @override
  List<AspectRatioPreset> get supportedAspectRatios => AspectRatioPreset.values;

  @override
  List<SyncMode> get supportedSyncModes => SyncMode.values;
}
