import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../localization/app_localization.dart';
import '../theme/app_theme.dart';
import '../services/quran_timing_service.dart';
import '../video_editing/video_contract.dart';
import '../widgets/studio_widgets.dart';

class QuranStudioScreen extends StatefulWidget {
  final LocalizedStrings strings;
  const QuranStudioScreen({super.key, required this.strings});

  @override
  State<QuranStudioScreen> createState() => _QuranStudioScreenState();
}

class _QuranStudioScreenState extends State<QuranStudioScreen> {
  final _timing = QuranTimingService();
  final _player = AudioPlayer();
  Map<String, dynamic> _audio = {};
  int _selectedSurah = 1;
  bool _loading = true;
  bool _busy = false;
  String? _error;
  QuranTimingSummary? _summary;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final audio = await _timing.loadSurahAudio();
      final summary = await _timing.getSummary();
      if (!mounted) return;
      setState(() { _audio = audio; _summary = summary; _loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Could not load the bundled Quran data: $e'; });
    }
  }

  Future<void> _playSelected() async {
    final item = _audio['$_selectedSurah'];
    if (item is! Map || item['audio_url'] is! String) return;
    setState(() { _busy = true; _error = null; });
    try {
      await _player.setUrl(item['audio_url'] as String);
      await _player.play();
    } catch (e) {
      if (mounted) setState(() { _error = 'Audio could not start. Check your internet connection and try again.'; });
    } finally {
      if (mounted) setState(() { _busy = false; });
    }
  }

  @override
  void dispose() { _player.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    const videoStub = PhaseOneVideoEngineStub();
    final selected = _audio['$_selectedSurah'];
    final duration = selected is Map ? (selected['duration'] as num?)?.toInt() ?? 0 : 0;
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.lg),
      children: [
        _studioCanvasPreview(),
        const SizedBox(height: AppSpacing.lg),
        _panel(
          title: 'Reciter · Mishari Rashid Al-Afasy',
          child: _loading
              ? const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()))
              : _error != null && _audio.isEmpty
                  ? Text(_error!, style: const TextStyle(color: Colors.orangeAccent))
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      DropdownButtonFormField<int>(
                        value: _selectedSurah,
                        isExpanded: true,
                        dropdownColor: AppColors.surfaceNavy,
                        decoration: const InputDecoration(labelText: 'Select surah', border: OutlineInputBorder()),
                        items: List.generate(114, (i) => i + 1).map((n) => DropdownMenuItem<int>(
                          value: n,
                          child: Text('Surah $n', style: const TextStyle(color: AppColors.textSilver)),
                        )).toList(),
                        onChanged: (n) async {
                          if (n == null) return;
                          await _player.stop();
                          if (mounted) setState(() { _selectedSurah = n; _error = null; });
                        },
                      ),
                      const SizedBox(height: 12),
                      Text('Audio source: QUL / QuranicAudio · ${_formatDuration(duration)}', style: const TextStyle(color: AppColors.textSilver, fontSize: 12)),
                      const SizedBox(height: 14),
                      StreamBuilder<PlayerState>(
                        stream: _player.playerStateStream,
                        builder: (context, snapshot) {
                          final playing = snapshot.data?.playing ?? false;
                          return Row(children: [
                            Expanded(child: FilledButton.icon(
                              onPressed: _busy ? null : (playing ? _player.pause : _playSelected),
                              icon: Icon(_busy ? Icons.hourglass_top : (playing ? Icons.pause_rounded : Icons.play_arrow_rounded)),
                              label: Text(_busy ? 'Loading audio…' : (playing ? 'Pause recitation' : 'Play recitation')),
                            )),
                            const SizedBox(width: 8),
                            IconButton(tooltip: 'Stop', onPressed: () => _player.stop(), icon: const Icon(Icons.stop_circle_outlined, color: AppColors.matteGold)),
                          ]);
                        },
                      ),
                      StreamBuilder<Duration?>(
                        stream: _player.durationStream,
                        builder: (context, ds) => StreamBuilder<Duration>(
                          stream: _player.positionStream,
                          builder: (context, ps) {
                            final total = ds.data?.inMilliseconds ?? 0;
                            final position = ps.data?.inMilliseconds ?? 0;
                            final max = total > 0 ? total.toDouble() : 1.0;
                            return Column(children: [
                              Slider(value: position.clamp(0, max).toDouble(), max: max, onChanged: total <= 0 ? null : (v) => _player.seek(Duration(milliseconds: v.round())), activeColor: AppColors.matteGold),
                              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                Text(_formatDuration(position ~/ 1000), style: const TextStyle(color: AppColors.textSilver, fontSize: 11)),
                                Text(_formatDuration(total ~/ 1000), style: const TextStyle(color: AppColors.textSilver, fontSize: 11)),
                              ]),
                            ]);
                          },
                        ),
                      ),
                      if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: Colors.orangeAccent))),
                    ]),
        ),
        const SizedBox(height: AppSpacing.lg),
        _panel(
          title: 'Advanced timing diagnostics',
          child: ExpansionTile(
            tilePadding: EdgeInsets.zero,
            collapsedIconColor: AppColors.matteGold,
            iconColor: AppColors.matteGold,
            title: const Text('QUL data integrity', style: TextStyle(color: AppColors.textIvory, fontWeight: FontWeight.w600)),
            subtitle: const Text('Technical details for review', style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
            children: [
              if (_summary == null) const Text('Timing summary unavailable.') else ...[
                _stat('Verses with bundled timing records', _summary!.verseCount.toString()),
                _stat('Word segments inspected', _summary!.segmentCount.toString()),
                _stat('Flagged for manual review', _summary!.reviewCount.toString(), warning: _summary!.reviewCount > 0),
                _stat('Zero-duration entries', _summary!.zeroDurationCount.toString(), warning: _summary!.zeroDurationCount > 0),
                _stat('Reversed-time entries', _summary!.reversedCount.toString(), warning: _summary!.reversedCount > 0),
              ],
              const Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: Text('Original timestamps are preserved. Word highlighting remains disabled until alignment is validated against recitation.', style: TextStyle(color: AppColors.textSilver, height: 1.45, fontSize: 12)),
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.lg),
        _panel(title: 'Video canvas · planned next', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(videoStub.enginePhaseStatus, style: const TextStyle(color: AppColors.textSilver, fontSize: 13, height: 1.4)),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: videoStub.supportedAspectRatios.map((preset) => Chip(label: Text(preset.label), avatar: const Icon(Icons.crop_portrait, size: 15))).toList()),
        ])),
      ],
    );
  }

  Widget _studioCanvasPreview() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadii.xl),
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [AppColors.emeraldPrimary, AppColors.midnightNavy, AppColors.midnightNavy],
        ),
        border: Border.all(color: AppColors.matteGold.withOpacity(0.38)),
        boxShadow: [BoxShadow(color: AppColors.matteGold.withOpacity(0.08), blurRadius: 24, spreadRadius: 1)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.auto_awesome, color: AppColors.matteGold, size: 16),
          const SizedBox(width: 8),
          const Expanded(child: Text('QURAN VIDEO STUDIO', style: TextStyle(color: AppColors.matteGoldLight, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.1))),
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: AppColors.emeraldContainer, borderRadius: BorderRadius.circular(30), border: Border.all(color: AppColors.emeraldContainerBorder)), child: const Text('9:16', style: TextStyle(color: AppColors.textIvory, fontSize: 10, fontWeight: FontWeight.bold))),
        ]),
        const SizedBox(height: 14),
        LayoutBuilder(
          builder: (context, constraints) {
            // Keep the canonical 9:16 canvas while allowing its height to
            // scale with the available width instead of clipping it at 310px.
            final canvasWidth = constraints.maxWidth.clamp(180.0, 460.0);
            return Center(
              child: SizedBox(
                width: canvasWidth,
                child: AspectRatio(
                  aspectRatio: 9 / 16,
                  child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const RadialGradient(center: Alignment(0, -0.35), radius: 1.05, colors: [AppColors.emeraldPrimary, AppColors.midnightNavy, AppColors.midnightNavy]),
                border: Border.all(color: AppColors.matteGold.withOpacity(0.42)),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Image.asset('assets/branding/ayah_studionext_logo.png', width: 104, height: 104, fit: BoxFit.cover),
                const SizedBox(height: 14),
                const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textIvory, fontSize: 19, height: 1.8, fontWeight: FontWeight.w600))),
                const SizedBox(height: 8),
                const Text('AL-MUZZAMMIL · 73:4', style: TextStyle(color: AppColors.matteGold, fontSize: 9, letterSpacing: 1.1)),
                const SizedBox(height: 18),
                Container(width: 72, height: 2, decoration: BoxDecoration(color: AppColors.matteGold.withOpacity(0.75), borderRadius: BorderRadius.circular(2))),
                  ]),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        const Center(child: Text('Preview concept · video rendering is not enabled yet', style: TextStyle(color: AppColors.textMuted, fontSize: 10))),
      ]),
    );
  }

  Widget _panel({required String title, required Widget child}) => Container(
    decoration: BoxDecoration(color: AppColors.surfaceNavy, borderRadius: BorderRadius.circular(AppRadii.lg), border: Border.all(color: AppColors.borderSubtle)),
    padding: const EdgeInsets.all(AppSpacing.lg),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: AppColors.matteGoldLight, fontSize: 15, fontWeight: FontWeight.w700)),
      const SizedBox(height: 14), child,
    ]),
  );

  Widget _stat(String label, String value, {bool warning = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: AppColors.textSilver, fontSize: 12))), Text(value, style: TextStyle(color: warning ? Colors.orangeAccent : AppColors.matteGoldLight, fontWeight: FontWeight.w700))]),
  );

  String _formatDuration(int seconds) {
    final d = Duration(seconds: seconds);
    final hours = d.inHours;
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final secs = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return hours > 0 ? '$hours:$minutes:$secs' : '${d.inMinutes}:$secs';
  }
}
