import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'localization/app_localization.dart';
import 'models/studio_models.dart';
import 'screens/adhkar_screen.dart';
import 'screens/home_screen.dart';
import 'screens/quran_studio_screen.dart';
import 'screens/settings_screen.dart';
import 'services/studio_service.dart';
import 'theme/app_theme.dart';
import 'widgets/studio_widgets.dart';

void main() {
  runApp(const AyahStudioNextApp());
}

class AyahStudioNextApp extends StatefulWidget {
  const AyahStudioNextApp({super.key});

  @override
  State<AyahStudioNextApp> createState() => _AyahStudioNextAppState();
}

class _AyahStudioNextAppState extends State<AyahStudioNextApp> {
  final StudioService _service = StudioService();

  @override
  void initState() {
    super.initState();
    _service.addListener(_onServiceUpdate);
  }

  @override
  void dispose() {
    _service.removeListener(_onServiceUpdate);
    _service.dispose();
    super.dispose();
  }

  void _onServiceUpdate() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final language = _service.selectedLanguage;
    final strings = AppLocalization.forLanguage(language);

    return MaterialApp(
      title: 'AyahStudioNext',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      locale: Locale(language.code),
      supportedLocales: const [
        Locale('en', ''),
        Locale('fr', ''),
        Locale('ar', ''),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: Directionality(
        textDirection: language.isRtl ? TextDirection.rtl : TextDirection.ltr,
        child: PopScope(
          canPop: _service.currentDestination == StudioDestination.home,
          onPopInvokedWithResult: (didPop, result) {
            if (didPop) return;
            if (_service.currentDestination != StudioDestination.home) {
              _service.selectDestination(StudioDestination.home);
            }
          },
          child: Scaffold(
            appBar: AppBar(
              title: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: AppColors.emeraldContainer,
                      borderRadius: BorderRadius.circular(AppRadii.sm),
                      border: Border.all(
                        color: AppColors.matteGold.withOpacity(0.55),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: const Text(
                      '۞',
                      style: TextStyle(
                        color: AppColors.matteGold,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          strings.appTitle,
                          style: const TextStyle(
                            color: AppColors.textIvory,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.2,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          strings.appSubtitle,
                          style: const TextStyle(
                            color: AppColors.matteGoldLight,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              actions: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
                  child: HeaderLanguageButton(
                    currentLanguage: language,
                    onLanguageSelected: _service.selectLanguage,
                    tooltip: strings.changeLanguageTooltip,
                  ),
                ),
              ],
            ),
            body: AnimatedSwitcher(
              duration: AppDurations.normal,
              child: _buildBody(strings),
            ),
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: _service.currentDestination.index,
              onTap: (index) {
                _service.selectDestination(StudioDestination.values[index]);
              },
              items: [
                BottomNavigationBarItem(
                  icon: const Icon(Icons.home_outlined),
                  activeIcon: const Icon(Icons.home),
                  label: strings.navHome,
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.video_collection_outlined),
                  activeIcon: const Icon(Icons.video_collection),
                  label: strings.navQuranStudio,
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.auto_stories_outlined),
                  activeIcon: const Icon(Icons.auto_stories),
                  label: strings.navAdhkar,
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.settings_outlined),
                  activeIcon: const Icon(Icons.settings),
                  label: strings.navSettings,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(LocalizedStrings strings) {
    switch (_service.currentDestination) {
      case StudioDestination.home:
        return HomeScreen(
          key: const ValueKey('home_screen'),
          strings: strings,
          selectedLanguage: _service.selectedLanguage,
          onLanguageSelected: _service.selectLanguage,
          onNavigate: _service.selectDestination,
        );
      case StudioDestination.quranStudio:
        return QuranStudioScreen(
          key: const ValueKey('quran_studio_screen'),
          strings: strings,
        );
      case StudioDestination.adhkar:
        return AdhkarScreen(
          key: const ValueKey('adhkar_screen'),
          strings: strings,
        );
      case StudioDestination.settings:
        return SettingsScreen(
          key: const ValueKey('settings_screen'),
          strings: strings,
          selectedLanguage: _service.selectedLanguage,
          onLanguageSelected: _service.selectLanguage,
        );
    }
  }
}
